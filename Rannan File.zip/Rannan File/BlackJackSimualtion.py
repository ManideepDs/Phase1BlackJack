##Rannan (TreeSearch)

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from Play_blackjack import BlackJack, GameStatus, log
from BlackJackState import decision, State
from TreeSearch import Node, rollout, decide_action, processedNodes, uniform, puct

class Statistics:
    def __init__(self):
        self.gamesize = []
        self.AIscore = []
        self.nodePros = []
        self.AI = []
        self.result = []
    
    def append(self,gamesize, AIscore, AI, nodePros, result):
        self.gamesize.append(gamesize)
        self.result.append(result)
        self.AIscore.append(AIscore)
        self.AI.append(AI)
        self.nodePros.append(nodePros)

if __name__ == "__main__":
    stats = Statistics()
    #gameSize = int(input("Enter the range for number of decks:"))
    for i in range(1,6):
        for j in range(100):
            game = BlackJack(numDecks=i)
            game.beginGame()
            game.playerTurn()
            state = State(game = game)
            node = Node(state = state)
            AI = ""
            #Choice of AI
            while game.log == log.Unfinished_Game:
                AI = input("Choose an AI: B: Baseline AI, T: Tree-based - ")
                if(AI == "T" or AI == "t" or AI == "B" or AI == "b"): break
                print("Please enter a valid input")
            if(AI == "B" or AI == "b"):
                game.dealerTurn()
                game.compare()
                print(game.gameStatus.name)
                stats.append(i, game.score, "BaseLine AI", 0, game.log.name)
                #Tree-Based
            else:
                nodesPros = 0
                while game.log == log.Unfinished_Game:
                    if node.state.isLeaf:
                            break
                    a, n, nump = decide_action(node.state,choose_method=uniform, num_rollouts=1000, max_depth = 10, verbose=True)
                    nodesPros += nump
                    state = n.children()[a].state
                    print("\nNumber of Processed nodes: ",nump)
                    if(state.childAction == decision.PositiveHit):
                        game.hit(member = game.dealer,sign="+")
                    elif(state.childAction == decision.NegativeHit):
                        game.hit(member = game.dealer,sign="-")
                    else:
                        game.stand()
                        print(game)
                        break
                    state = State(game = game)
                    node = Node(state = state)
                    print(game)
                stats.append(i,game.score,"Tree Based Mcts",nodesPros,game.log.name)
    stats_df = pd.DataFrame(list(zip(stats.gamesize, stats.AIscore, stats.nodePros, stats.AI, stats.result)),
    columns = ['Gamesize','AIscore','NodesProcessed',"AI",'Result'])
    print(stats_df.head())
    print(stats_df.tail())
    print(stats_df.shape)
    #Customize your path
    stats_df.to_csv (r'C:\Users\kmani\OneDrive - Syracuse University\Sem III\AI\Project\export_dataframe.csv', index = False, header=True)
    """
    #sns.set_theme(style="ticks")
    for i in range(5):
        fig, axs = plt.subplots(1,3, figsize=(10,10))
        df = stats_df.loc[stats_df['Gamesize'] == i+1]
        sns.countplot(data = df, x = "Result", ax = axs[0])
        sns.histplot(data = df, x ='DealerScore',hue="Result", ax = axs[1])
        sns.histplot(data = df, x ='PlayerScore',hue="Result", ax = axs[2])
        plt.title("GameSize = "+str(i+1))
        plt.show()
    #sns.countplot(data = stats_df, x="Gamesize", hue="Result")
    #sns.pairplot(stats_df, hue="Result")
    """
